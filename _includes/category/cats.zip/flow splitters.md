# flow-splitters

# Flow-Splitter for Oxygen Supply

# The Problem:

Flow splitter for diversification of oxygen delivery. Each outlet with an independent flowmeter for independently controlled oxygen flow rates. Full scale is graduated in litres per minute (L/min). The device is connected to a single oxygen supply (e.g. concentrator). Input pressure: 50–350 kPa.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*