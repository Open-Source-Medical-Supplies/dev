# non-contact-thermometers

# OSCMS - Non-Contact Thermometer

# The Problem:

- Taking someone’s temperature is one indication of potential COVID19 infection. Using a regular thermometer requires disinfection between patients. Non-contact thermometers allow for rapid testing without disinfection.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*