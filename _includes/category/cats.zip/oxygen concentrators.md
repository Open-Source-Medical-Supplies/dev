# oxygen-concentrators

# OSCMS - Oxygen Mask

# The Problem:

Connection tube, reservoir bag and valve, high-concentration, non-sterile, single-use; different sizes: adult, paediatric

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

[https://www.accessdata.fda.gov/cdrh_docs/pdf17/K172365.pdf](https://www.accessdata.fda.gov/cdrh_docs/pdf17/K172365.pdf)

%CO2 accuracy and respiration rate

Biocomp

Shelf life

Gas sampling connections

Size

Profile

Face strap

Internal volume

Access ports and Max instrument size

Entrainment vents

# Assembly/Fabrication Requirements:

# Projects/Resources:

[https://www.accessdata.fda.gov/cdrh_docs/pdf17/K172365.pdf](https://www.accessdata.fda.gov/cdrh_docs/pdf17/K172365.pdf)

[https://www.accessdata.fda.gov/cdrh_docs/pdf10/K102299.pdf](https://www.accessdata.fda.gov/cdrh_docs/pdf10/K102299.pdf)

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*