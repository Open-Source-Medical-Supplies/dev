# venturi-masks

# OSCMS - Venturi Masks

# The Problem:

Venturi mask, w/percent O2 Lock + 2.1 m tubing, non-sterile, single-use; different sizes: adult, paediatric.

They are specifically important to managing COVID-19 because of their ability to provide a constant, pre-determined level of oxygen which not only acts as supplemental oxygen but also useful in controlling a patient's carbon dioxide level.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*