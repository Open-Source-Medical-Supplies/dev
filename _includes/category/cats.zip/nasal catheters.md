# nasal-catheters

# OSCMS - Nasal Catheters

# The Problem:

Flexible nasal catheter with multiple holes (6 to 12 lateral eyes) at distal end. Oxygen and air/oxygen mixture compatibility, as per ISO 15001. Proximal end with connector. Sterile, single-use. Diameter: 8 Fr. Length: 40 cm with lateral eyes, sterile, single-use.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

[Medtronic, 1527031, Medtronic ENT Epistat Nasal Catheter](https://www.esutures.com/product/1-expired/43-medtronic/1106-ent/46255905-medtronic-ent-epistat-nasal-catheter-1527031/)

# Reviewed Designs: