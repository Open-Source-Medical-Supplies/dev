# nasal-cannulas

# OSCMS - Nasal Cannulas

# The Problem:

- Oxygen cannula (nasal prongs) are plastic tubes shaped as two prongs delivering air/oxygen mixture into the nasal cavities and connected to an oxygen administration circuit; cannulae can be designed for low-flow applications (0–15 L/min range in general) or high flow (> 15 L/min typically). Oxygen and air/oxygen mixture compatibility, as per ISO 15001; different sizes: adult, paediatric, neonatal

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*