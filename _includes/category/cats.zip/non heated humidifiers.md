# non-heated-humidifiers

# OSCMS - Non-Heated Humidifier

# The Problem:

The humidifier is inserted in the inspiratory line of a breathing circuit to add moisture to the breathing gases for administration to a patient. The bubbling bottle humidifier is a sealed container filled with water and connected inline into the breathing circuit. The medical gas mixture flows through the water inside the bottle and is enriched in humidity. This type of humidifier does not heat the gas. Should be compatible with oxygen concentrator, including necessary hose connectors.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*