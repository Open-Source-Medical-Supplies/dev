# thorpe-tube-flowmeter

# Thorpe Tube Flowmeter

# The Problem:

The Thorpe tube flowmeter is composed of inlet and outlet ports, a regulator, a valve and a clear tapered measuring tube. It is suitable for connection to various medical gas sources, such as a centralized system, cylinders, concentrators or compressors; standard (absolute, non-compensated) and pressure-compensated flowmeter versions; suitable for specific flow ranges.

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

# Assembly/Fabrication Requirements:

# Projects/Resources:

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*