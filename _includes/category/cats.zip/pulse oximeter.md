# pulse-oximeter

# Pulse Oximeter

# The Problem:

- Compact portable device to monitor haemoglobin oxygen saturation and calculate the pulse rate of a patient; finger tip or tabletop; battery powered or line powered. SpO2 detection to include the range 70–100% SpO2 resolution: 1% or less Pulse rate detection to include the range 30–240 bpm Pulse rate resolution: 1 bpm or less

# Current Global Resources:

# Worst Case Expectation:

# Engineering Requirements:

- Complies with ISO 80601-2-61:2011, or equivalent.

# Assembly/Fabrication Requirements:

# Projects/Resources:

- [helpfulengineering.slack.com](http://helpfulengineering.slack.com/) #hardware-oximeter-prototype
- [Instructable on building a pulse oximeter](https://www.instructables.com/id/Pulse-Oximeter-With-Much-Improved-Precision/)

# Reviewed Designs:

*This section is for product designs (links to instructions or downloadable packages) that have been reviewed and approved by medical professionals. When adding a design to this list, please include the (approximate) date of approval, the group or organization that reviewed it, and any modifications they recommend.*